param(
  [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

$SourceRoot = Join-Path $PSScriptRoot "src"
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupRoot = Join-Path $ProjectRoot ".studio-rd-backup-bloqueios-$Timestamp"

$Files = @(
  "src\components\agenda\BloqueiosAgendaPage.tsx",
  "src\routes\admin.bloqueios.tsx",
  "src\routes\funcionario.bloqueios.tsx",
  "src\lib\api\bloqueio-agenda.functions.ts"
)

if (-not (Test-Path (Join-Path $ProjectRoot "package.json"))) {
  throw "Não encontrei package.json em '$ProjectRoot'. Execute este script a partir da raiz do studio-rd-canvas ou informe -ProjectRoot."
}

Write-Host "Studio RD Black - aplicando novo fluxo de bloqueio de agenda" -ForegroundColor Cyan
Write-Host "Projeto: $ProjectRoot"

foreach ($RelativePath in $Files) {
  $Source = Join-Path $SourceRoot $RelativePath
  $Destination = Join-Path $ProjectRoot $RelativePath

  if (-not (Test-Path $Source)) {
    throw "Arquivo do pacote não encontrado: $Source"
  }

  if (Test-Path $Destination) {
    $BackupDestination = Join-Path $BackupRoot $RelativePath
    $BackupDirectory = Split-Path $BackupDestination -Parent
    New-Item -ItemType Directory -Force -Path $BackupDirectory | Out-Null
    Copy-Item -Force $Destination $BackupDestination
  }

  $DestinationDirectory = Split-Path $Destination -Parent
  New-Item -ItemType Directory -Force -Path $DestinationDirectory | Out-Null
  Copy-Item -Force $Source $Destination

  Write-Host "OK  $RelativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "Arquivos aplicados." -ForegroundColor Green
Write-Host "Backup dos arquivos anteriores: $BackupRoot" -ForegroundColor Yellow
Write-Host ""
Write-Host "Agora execute:" -ForegroundColor Cyan
Write-Host "  npm run typecheck"
Write-Host "  npm run build"
Write-Host "  git diff -- src/components/agenda/BloqueiosAgendaPage.tsx src/routes/admin.bloqueios.tsx src/routes/funcionario.bloqueios.tsx src/lib/api/bloqueio-agenda.functions.ts"
